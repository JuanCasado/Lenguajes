package fuente;

public enum Nombres{
    name, eng, es
};