package fuente;

public enum Content {
    json, dot, svg
};
