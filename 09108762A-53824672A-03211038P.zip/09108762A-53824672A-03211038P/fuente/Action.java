package fuente;

public enum Action {
    skip, saveDot, saveSvg, saveBoth
};