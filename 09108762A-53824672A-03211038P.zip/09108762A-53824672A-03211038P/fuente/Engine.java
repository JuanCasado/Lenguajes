package fuente;

public enum Engine{
    neato,
    dot,
    circo,
    fdp,
    osage,
    twopi
};