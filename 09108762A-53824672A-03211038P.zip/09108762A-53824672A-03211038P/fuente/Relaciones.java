package fuente;

enum Relaciones {
    from, to
};