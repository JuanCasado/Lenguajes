package fuente;

enum JSONkey {
    reverse_, from, to, gender,number,wordType,typeOf,isList,isOptional,multiMax,multiMin
};